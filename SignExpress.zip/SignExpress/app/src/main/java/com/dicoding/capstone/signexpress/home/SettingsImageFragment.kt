package com.dicoding.capstone.signexpress.home

import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.databinding.DataBindingUtil
import com.dicoding.capstone.signexpress.R
import com.dicoding.capstone.signexpress.databinding.FragmentProfileBinding

class SettingsImageFragment : Fragment() {
    private lateinit var binding: FragmentProfileBinding
    private var currentImageUri: String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentProfileBinding.inflate(inflater, container, false)

        binding.btnEditPhoto.setOnClickListener {
            showImageSelectionPopup()
        }

        return binding.root
    }

    private fun showImageSelectionPopup() {
        val popupMenu = PopupMenu(requireContext(), binding.btnEditPhoto)
        popupMenu.menuInflater.inflate(R.menu.image_selection_menu, popupMenu.menu)
        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.galleryOption -> openGallery()
                R.id.cameraOption -> openCamera()
            }
            true
        }
        popupMenu.show()
    }

    private fun openGallery() {
        launcherGallery.launch("image/*")
    }

    private val launcherGallery = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            currentImageUri = uri.toString()
            showImage()
        } else {
            Log.d("Photo Picker", "No media selected")
        }
    }

    private fun openCamera() {
        Toast.makeText(requireContext(), "Fitur ini belum tersedia", Toast.LENGTH_SHORT).show()
    }

    private fun showImage() {
        currentImageUri?.let {
            Log.d("Image URI", "showImage: $it")
            binding.previewImageView.setImageURI(Uri.parse(it))
        }
    }

    private fun startCameraX() {
        Toast.makeText(requireContext(), "Fitur ini belum tersedia", Toast.LENGTH_SHORT).show()
    }

    private fun uploadImage() {
        Toast.makeText(requireContext(), "Fitur ini belum tersedia", Toast.LENGTH_SHORT).show()
    }
}