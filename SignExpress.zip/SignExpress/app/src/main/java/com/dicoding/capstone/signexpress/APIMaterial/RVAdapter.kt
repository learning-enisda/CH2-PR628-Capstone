package com.dicoding.capstone.signexpress.APIMaterial

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.capstone.signexpress.R

class RVAdapter(
    private val context: Context,
    private val dataList: ArrayList<ResponseModelMaterial>,
    private val itemClickListener: (ResponseModelMaterial) -> Unit
) : RecyclerView.Adapter<RVAdapter.MyViewHolder>() {

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val topicSubject: TextView = view.findViewById(R.id.title_subject)
        val descSubject: TextView = view.findViewById(R.id.desc_subject)
        val recyclerSubject: CardView = view.findViewById(R.id.recycler_subject)

        init {
            recyclerSubject.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val currentItem = dataList[position]
                    itemClickListener(currentItem)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.item_lesson, parent, false)
        return MyViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = dataList[position]
        holder.topicSubject.text = currentItem.name
        holder.descSubject.text = currentItem.name
    }

    fun setData(filterDataList: ArrayList<ResponseModelMaterial>) {
        dataList.clear()
        dataList.addAll(filterDataList)
        notifyDataSetChanged()

    }
}