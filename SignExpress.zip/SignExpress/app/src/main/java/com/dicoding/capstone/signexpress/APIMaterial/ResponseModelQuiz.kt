package com.dicoding.capstone.signexpress.APIMaterial

data class ResponseModelQuiz(
    val id: String,
    val image: String,
    val question: String,
    val choiceA: String,
    val choiceB: String,
    val choiceC: String,
    val choiceD: String,
)
