package com.dicoding.capstone.signexpress.home

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.dicoding.capstone.signexpress.R

class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
    }
}