package com.dicoding.capstone.signexpress.LoginRegister

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.airbnb.lottie.LottieAnimationView
import com.dicoding.capstone.signexpress.CustomView.EmailEditText
import com.dicoding.capstone.signexpress.CustomView.PasswordEditText
import com.dicoding.capstone.signexpress.MainActivity
import com.dicoding.capstone.signexpress.databinding.ActivityLoginBinding
import com.dicoding.capstone.signexpress.R

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var edLoginEmail: EmailEditText
    private lateinit var edLoginPassword: PasswordEditText
    private lateinit var edLoginButton: Button
    private lateinit var edLoginToRegister: TextView
    private lateinit var edLoginLoading: LottieAnimationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val preferences = getSharedPreferences("loginPref", Context.MODE_PRIVATE)
        val loginViewModel = ViewModelProvider(this, ViewModelFactory(preferences))[LoginViewModel::class.java]

        val intentToRegister = Intent(this@LoginActivity, RegisterActivity::class.java)
        val intentToMain = Intent(this@LoginActivity, MainActivity::class.java)

        edLoginEmail = binding.editTextEmail
        edLoginPassword = binding.editTextPassword
        edLoginButton = binding.btnMasuk
        edLoginToRegister = binding.tvBelumpunya
        edLoginLoading = binding.loginLoading

        loginViewModel.isLoading.observe(this) {
            if (it) {
                edLoginLoading.visibility = View.VISIBLE
                edLoginLoading.playAnimation()
            } else {
                edLoginLoading.visibility = View.INVISIBLE
                edLoginLoading.cancelAnimation()
            }
        }

        edLoginButton.setOnClickListener {
            if (!edLoginEmail.isError() && !edLoginPassword.isError()) {
                loginViewModel.getLogin(edLoginEmail.text.toString().lowercase(), edLoginPassword.text.toString())
            } else {
                Toast.makeText(this, R.string.login_error_toast, Toast.LENGTH_SHORT).show()
            }
        }

        loginViewModel.acceptance.observe(this) { isLoginSuccessful ->
            if (isLoginSuccessful) {
                startActivity(intentToMain)
            } else {
                Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show()
            }
        }

        loginViewModel.message.observe(this) { message ->
            if (message == "Failure") {
                Toast.makeText(this, R.string.api_failure, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }
        }

        edLoginToRegister.setOnClickListener {
            startActivity(intentToRegister)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }
}