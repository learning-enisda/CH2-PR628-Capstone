package com.dicoding.capstone.signexpress.APIMaterial

data class ResponseModelMaterial(
    val id: Int,
    val name: String,
    val username: String,
    val email: String,
)

/*
Rencananya
data class ResponseModelMaterial(
    val topic: String, //Judul Topik
    val total: String, //Jumlah materi dalam satu topik
    val materi: String, //Judul Materi
    val image: String, //gambar materi
)
 */
