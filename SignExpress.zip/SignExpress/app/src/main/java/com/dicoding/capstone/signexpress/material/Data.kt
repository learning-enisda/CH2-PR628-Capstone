package com.dicoding.capstone.signexpress.material

import com.dicoding.capstone.signexpress.R

fun generateMateri () : List<Materi> {
    return listOf(
        Materi(1, R.drawable.a, "A", "Alfabet"),
        Materi(2, R.drawable.b, "B", "Alfabet"),
        Materi(3, R.drawable.c, "C", "Alfabet"),
        Materi(4, R.drawable.d, "D", "Alfabet"),
        Materi(5, R.drawable.e, "E", "Alfabet"),
    )
}

data class Materi (
    val id: Int,
    val gambar: Int,
    val judul: String,
    val desc: String,
)
