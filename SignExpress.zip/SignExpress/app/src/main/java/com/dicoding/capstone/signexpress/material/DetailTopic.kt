package com.dicoding.capstone.signexpress.material

import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.dicoding.capstone.signexpress.R

class DetailTopic : AppCompatActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_topic)

        val ivBackD = findViewById<ImageView>(R.id.ivBackD)
        val detailMateri = findViewById<TextView>(R.id.detail_materi)
        val detailKuis = findViewById<TextView>(R.id.detail_kuis)

        ivBackD.setOnClickListener(this)
        detailMateri.setOnClickListener(this)
        detailKuis.setOnClickListener(this)
    }

    override fun onClick(view: View?) {
        when (view?.id) {
            R.id.ivBackD -> {
                finish()
            }
            R.id.detail_materi -> {
                val intent = Intent(this, MainMaterialActivity::class.java)
                startActivity(intent)
            }
            R.id.detail_kuis -> {
                val intent = Intent(this, QuizActivity::class.java)
                startActivity(intent)
            }
        }
    }
}