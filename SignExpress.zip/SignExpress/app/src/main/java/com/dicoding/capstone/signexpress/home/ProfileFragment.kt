package com.dicoding.capstone.signexpress.home

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.preference.Preference
import com.dicoding.capstone.signexpress.LoginRegister.LoginActivity
import com.dicoding.capstone.signexpress.R
import com.dicoding.capstone.signexpress.mainViewModel
import com.dicoding.capstone.signexpress.welcoming.WelcomingActivity
import kotlinx.coroutines.launch


class ProfileFragment : Fragment() {

    private val REQUEST_IMAGE_GALLERY = 1
    private val REQUEST_IMAGE_CAMERA = 2
    private val REQUEST_CAMERA_PERMISSION = 3

    private lateinit var btnChangePhoto: ImageButton
    private lateinit var imgProfile: ImageView
    private lateinit var logOut: TextView
    private lateinit var preferences: SharedPreferences

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        btnChangePhoto = view.findViewById<ImageButton>(R.id.btn_edit_photo)
        imgProfile = view.findViewById(R.id.previewImageView)

        val moreProfile = view.findViewById<ImageView>(R.id.more_icn)
        moreProfile.setOnClickListener {
            val intent = Intent(activity, SettingsActivity::class.java)
            startActivity(intent)
        }

        val moreAbout = view.findViewById<ImageView>(R.id.more_abt)
        moreAbout.setOnClickListener {
            val intent = Intent(activity, AboutActivity::class.java)
            startActivity(intent)
        }

        btnChangePhoto.setOnClickListener {
            showImagePickerDialog()
        }

        preferences = requireContext().getSharedPreferences("nama_pref", Context.MODE_PRIVATE)

        logOut = view.findViewById(R.id.keluar_profile)
        logOut.setOnClickListener {
            if (::preferences.isInitialized) {
                logout(requireContext())
            } else {
                Toast.makeText(requireContext(), "Preferences not initializd", Toast.LENGTH_SHORT).show()
            }
        }

        return view

    }

    private fun showImagePickerDialog() {
        val options = arrayOf<CharSequence>("Ambil Foto", "Pilih dari Galeri")
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Silakan pilih!")
        builder.setItems(options) { dialog, which ->
            when (which) {
                0 -> {
                    if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        openCamera()
                    } else {
                        requestCameraPermission()
                    }
                }
                1 -> openGallery()
            }
        }

        val dialog = builder.create()
        dialog.show()
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_IMAGE_GALLERY)
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, REQUEST_IMAGE_CAMERA)
    }

    private fun requestCameraPermission() {
        ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera()
            } else {
                // Izin kamera ditolak oleh pengguna
                // Tampilkan pesan atau beri pengguna opsi untuk mengizinkan akses kamera melalui pengaturan aplikasi
                Toast.makeText(requireContext(), "Izin kamera diperlukan untuk menggunakan fitur ini.", Toast.LENGTH_SHORT).show()
                showPermissionSettings()
            }
        }
    }

    private fun showPermissionSettings() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Izin Kamera Diperlukan")
        builder.setMessage("Izin kamera diperlukan untuk menggunakan fitur ini. Buka pengaturan aplikasi untuk mengizinkan akses kamera.")
        builder.setPositiveButton("Buka Pengaturan") { dialog, which ->
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri = Uri.fromParts("package", requireActivity().packageName, null)
            intent.data = uri
            startActivity(intent)
        }
        builder.setNegativeButton("Batal") { dialog, which ->
            dialog.dismiss()
        }
        builder.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_IMAGE_GALLERY -> {
                    val imageUri = data?.data
                    imgProfile.setImageURI(imageUri)
                }
                REQUEST_IMAGE_CAMERA -> {
                    val photo = data?.extras?.get("data") as Bitmap
                    imgProfile.setImageBitmap(photo)
                }
            }
        }
    }

    private fun logout(context: Context) {
        // Clear the user token or perform any other necessary logout operations
        mainViewModel.clearToken(preferences)

        // Create an intent to navigate to the Welcoming
        val intentToWelcoming = Intent(context, WelcomingActivity::class.java)
        intentToWelcoming.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

        // Start the LoginActivity and finish the current activity
        startActivity(intentToWelcoming)
        activity?.finish()
    }

}