package com.dicoding.capstone.signexpress.material

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.capstone.signexpress.R

class MateriAdapter(private val listMateri: List<Materi>) : RecyclerView.Adapter<MateriAdapter.MateriViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MateriViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_lesson, parent, false)
        return MateriViewHolder(view)
    }

    override fun onBindViewHolder(holder: MateriViewHolder, position: Int) {
        val materi = listMateri[position]
        holder.bind(materi)
    }

    override fun getItemCount(): Int {
        return listMateri.size
    }

    inner class MateriViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imageMateri: ImageView = itemView.findViewById(R.id.img_subject_home)
        private val textJudulMateri: TextView = itemView.findViewById(R.id.title_subject)
        private val textKategoriMateri: TextView = itemView.findViewById(R.id.desc_subject)

        fun bind(materi: Materi) {
            imageMateri.setImageResource(materi.foto)
            textJudulMateri.text = materi.judul
            textKategoriMateri.text = materi.kategori
        }
    }
}