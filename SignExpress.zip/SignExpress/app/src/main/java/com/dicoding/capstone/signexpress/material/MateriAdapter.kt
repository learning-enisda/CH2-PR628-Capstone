// MateriAdapter.kt
package com.dicoding.capstone.signexpress.material

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.capstone.signexpress.R

class MateriAdapter(private var materiList: List<Materi>, private val onItemClick: (Materi) -> Unit) :
    RecyclerView.Adapter<MateriAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_lesson, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val materi = materiList[position]
        holder.bind(materi)
        holder.itemView.setOnClickListener {
            onItemClick(materi)
        }
    }

    override fun getItemCount(): Int {
        return materiList.size
    }

    fun setData(newData: List<Materi>) {
        materiList = newData
        notifyDataSetChanged()
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imageView: ImageView = itemView.findViewById(R.id.img_subject_home)
        private val textViewJudul: TextView = itemView.findViewById(R.id.title_subject)
        private val textViewDesc: TextView = itemView.findViewById(R.id.desc_subject)

        fun bind(materi: Materi) {
            imageView.setImageResource(materi.gambar)
            textViewJudul.text = materi.judul
            textViewDesc.text = materi.desc
        }
    }
}