package com.dicoding.capstone.signexpress.APILoginRegister

import com.dicoding.capstone.signexpress.model.LoginResponse
import com.dicoding.capstone.signexpress.model.RegisterResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

data class LoginRequest(val email: String, val password: String)
data class RegisterRequest(val name: String, val email: String, val password: String)

interface ApiService {
    @POST("/v1/login")
    fun login(@Body request: LoginRequest): Call<LoginResponse>

    @POST("/v1/register")
    fun register(@Body request: RegisterRequest): Call<RegisterResponse>
}