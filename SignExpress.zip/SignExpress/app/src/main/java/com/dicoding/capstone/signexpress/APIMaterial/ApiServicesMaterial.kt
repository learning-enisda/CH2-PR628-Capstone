package com.dicoding.capstone.signexpress.APIMaterial

import retrofit2.Call
import retrofit2.http.GET


interface ApiServicesMaterial {

    @GET("users")
    fun getUsers(): Call<ArrayList<ResponseModelMaterial>>
}



/*
interface ApiServicesMaterial {

    //endpoint main
    @GET("material/main")
    fun getTopic(): Call<ArrayList<ResponseModelMaterial>>

    //endpoint quiz
    @GET("material/quiz")
    fun getQuiz(): Call<ArrayList<ResponseModelQuiz>>

}

 */