package com.dicoding.capstone.signexpress.material

import com.dicoding.capstone.signexpress.R

val listMateri = listOf(
    Materi(R.drawable.a, "A", "Alfabet"),
    Materi(R.drawable.b, "B", "Alfabet"),
    Materi(R.drawable.c, "C", "Alfabet"),
    Materi(R.drawable.d, "D", "Alfabet"),
    Materi(R.drawable.e, "E", "Alfabet"),
    // Tambahkan data Materi sesuai kebutuhan
)