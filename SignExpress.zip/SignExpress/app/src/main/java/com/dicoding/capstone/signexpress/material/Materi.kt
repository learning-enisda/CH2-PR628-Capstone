package com.dicoding.capstone.signexpress.material


class Materi (
    var foto : Int,
    var judul : String,
    var kategori: String,
)