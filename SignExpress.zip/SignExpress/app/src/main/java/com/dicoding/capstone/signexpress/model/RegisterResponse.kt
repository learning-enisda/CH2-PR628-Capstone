package com.dicoding.capstone.signexpress.model

class RegisterResponse (
    val error: Boolean,
    val message: String
)