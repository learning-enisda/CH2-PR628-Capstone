package com.dicoding.capstone.signexpress.home

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.capstone.signexpress.APIMaterial.ApiClient
import com.dicoding.capstone.signexpress.APIMaterial.RVAdapter
import com.dicoding.capstone.signexpress.APIMaterial.ResponseModelMaterial
import com.dicoding.capstone.signexpress.databinding.FragmentHomeBinding
import com.dicoding.capstone.signexpress.material.DetailTopic
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var adapter: RVAdapter
    private lateinit var fullDataList: ArrayList<ResponseModelMaterial>

    private var filterDataList: ArrayList<ResponseModelMaterial> = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = RVAdapter(requireContext(), arrayListOf()) {
            item ->
            val intent = Intent(requireContext(), DetailTopic::class.java)
            intent.putExtra("topicId", item.id)
            startActivity(intent)
        }
        binding.recyclerMain.adapter = adapter
        binding.recyclerMain.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerMain.setHasFixedSize(true)

        binding.searchview.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterData(newText ?: "")
                return true
            }
        })

        remoteGetUsers()
    }

    private fun remoteGetUsers() {
        ApiClient.getService().getUsers().enqueue(object : Callback<ArrayList<ResponseModelMaterial>> {
            override fun onResponse(
                call: Call<ArrayList<ResponseModelMaterial>>,
                response: Response<ArrayList<ResponseModelMaterial>>
            ) {
                if (response.isSuccessful) {
                    val data = response.body()
                    data?.let {
                        fullDataList = it
                        filterDataList.addAll(it)
                        setDataToAdapter(it)
                    }
                } else {
                    Log.e("Error", "Response not successful: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<ArrayList<ResponseModelMaterial>>, t: Throwable) {
                Log.e("Error", "Request failed: ${t.message}")
            }
        })
    }

    private fun setDataToAdapter(data: ArrayList<ResponseModelMaterial>) {
        adapter.setData(data)
    }

    private fun filterData(query: String) {
        filterDataList.clear()
        if (query.isEmpty()) {
            filterDataList.addAll(fullDataList)
        } else {
            for (item in fullDataList) {
                if (item.name.contains(query, ignoreCase = true)) {
                    filterDataList.add(item)
                }
            }
        }
        adapter.setData(filterDataList)
    }
}