package com.dicoding.capstone.signexpress.home

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.capstone.signexpress.databinding.FragmentHomeBinding
import com.dicoding.capstone.signexpress.material.DetailTopic
import com.dicoding.capstone.signexpress.material.MainMaterialActivity
import com.dicoding.capstone.signexpress.material.Materi
import com.dicoding.capstone.signexpress.material.MateriAdapter
import com.dicoding.capstone.signexpress.material.generateMateri



class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var adapter: MateriAdapter
    private lateinit var fullDataList: List<Materi>
    private var filterDataList: MutableList<Materi> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inisialisasi adapter dengan data kosong
        adapter = MateriAdapter(emptyList()) { item ->
            val intent = Intent(requireContext(), MainMaterialActivity::class.java)
            intent.putExtra("topicId", item.id)
            startActivity(intent)
        }

        binding.recyclerMain.adapter = adapter
        binding.recyclerMain.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerMain.setHasFixedSize(true)

        // Mengisi adapter dengan data materi statis
        fullDataList = generateMateri()
        setDataToAdapter(fullDataList)

        binding.searchview.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterData(newText.orEmpty())
                return true
            }
        })
    }

    private fun setDataToAdapter(data: List<Materi>) {
        adapter.setData(data)
    }

    private fun filterData(query: String) {
        filterDataList.clear()
        if (query.isEmpty()) {
            filterDataList.addAll(fullDataList)
        } else {
            for (item in fullDataList) {
                if (item.judul.contains(query, ignoreCase = true)) {
                    filterDataList.add(item)
                }
            }
        }
        adapter.setData(filterDataList)
    }
}