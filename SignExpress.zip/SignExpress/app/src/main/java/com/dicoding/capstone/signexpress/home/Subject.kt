package com.dicoding.capstone.signexpress.home


data class Subject(val title: String,
                   val description: String)
