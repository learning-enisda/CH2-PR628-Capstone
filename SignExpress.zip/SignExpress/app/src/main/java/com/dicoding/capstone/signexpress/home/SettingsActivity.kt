package com.dicoding.capstone.signexpress.home

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.dicoding.capstone.signexpress.R
import com.dicoding.capstone.signexpress.databinding.SettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: SettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settings)
        if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.settings, SettingsFragment())
                .commit()
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            val ivBackL: ImageView? = activity?.findViewById(R.id.ivBackL)
            ivBackL?.setOnClickListener {
                val navController = findNavController()
                navController.navigate(R.id.profileFragment)
            }

            val profileCategory: Preference? = findPreference("profileCategory")
            profileCategory?.onPreferenceClickListener = Preference.OnPreferenceClickListener {
                val navController = Navigation.findNavController(requireActivity(), R.id.settings)
                navController.navigate(R.id.profileFragment)
                true
            }
        }
    }
}