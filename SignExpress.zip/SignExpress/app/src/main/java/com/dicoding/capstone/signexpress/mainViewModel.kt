package com.dicoding.capstone.signexpress

import android.content.SharedPreferences
import androidx.lifecycle.ViewModel

class mainViewModel(private val preferences: SharedPreferences) : ViewModel() {
    companion object {
        fun clearToken(preferences: SharedPreferences) {
            preferences.edit().clear().apply()
        }
    }
}