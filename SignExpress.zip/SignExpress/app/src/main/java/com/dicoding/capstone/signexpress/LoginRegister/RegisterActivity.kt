package com.dicoding.capstone.signexpress.LoginRegister

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.airbnb.lottie.LottieAnimationView
import com.dicoding.capstone.signexpress.CustomView.CustomEditText
import com.dicoding.capstone.signexpress.CustomView.EmailEditText
import com.dicoding.capstone.signexpress.CustomView.PasswordEditText
import com.dicoding.capstone.signexpress.R
import com.dicoding.capstone.signexpress.databinding.ActivityRegisterBinding



class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var edRegisterButton: Button
    private lateinit var edRegisterToLogin: TextView
    private lateinit var edRegisterName: CustomEditText
    private lateinit var edRegisterEmail: EmailEditText
    private lateinit var edRegisterPassword: PasswordEditText
    private lateinit var edRegisterLoading: LottieAnimationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val registerViewModel = ViewModelProvider(this)[RegisterViewModel::class.java]

        val intent = Intent(this@RegisterActivity, LoginActivity::class.java)

        edRegisterName = binding.editRegisterFullName
        edRegisterEmail = binding.editTextEmail
        edRegisterPassword = binding.editTextPassword
        edRegisterButton = binding.btnDaftar
        edRegisterToLogin = binding.tvSudahpunya
        edRegisterLoading = binding.registerLoading

        edRegisterToLogin.setOnClickListener {
            startActivity(intent)
        }

        registerViewModel.isLoading.observe(this){
            if(it){
                edRegisterLoading.visibility = View.VISIBLE
                edRegisterLoading.playAnimation()
            } else {
                edRegisterLoading.visibility = View.INVISIBLE
                edRegisterLoading.cancelAnimation()
            }
        }

        edRegisterButton.setOnClickListener {
            if(!edRegisterName.isError() && !edRegisterEmail.isError() && !edRegisterPassword.isError()){
                registerViewModel.getRegister(edRegisterName.text.toString(), edRegisterEmail.text.toString().lowercase(), edRegisterPassword.text.toString())
            } else {
                Toast.makeText(this, R.string.login_error_toast, Toast.LENGTH_SHORT).show()
            }
        }

        registerViewModel.acceptance.observe(this){
            if (it) {
                startActivity(intent)
            }
        }

        registerViewModel.message.observe(this){
            if (it == "Failure"){
                Toast.makeText(this, R.string.api_failure, Toast.LENGTH_SHORT).show()
            }
            else{
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
            }
        }
    }
}