package com.dicoding.capstone.signexpress.welcoming

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil.setContentView
import com.dicoding.capstone.signexpress.LoginRegister.LoginActivity
import com.dicoding.capstone.signexpress.LoginRegister.RegisterActivity
import com.dicoding.capstone.signexpress.MainActivity
import com.dicoding.capstone.signexpress.R

class WelcomingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcoming)

        val btnWelMasuk = findViewById<Button>(R.id.btn_wel_masuk)
        val btnWelDaftar = findViewById<Button>(R.id.btn_wel_daftar)

        btnWelMasuk.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        btnWelDaftar.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onStart() {
        super.onStart()

        // Check if user is already logged in
        val isLoggedIn = checkIfUserIsLoggedIn()

        if (isLoggedIn) {
            // User is already logged in, navigate to MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun checkIfUserIsLoggedIn(): Boolean {
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        return sharedPreferences.getBoolean("isLoggedIn", false)

    }
}