package com.dicoding.capstone.signexpress.model

/*
data class AuthResponse(
    val user: User,
    val token: String,
)

 */