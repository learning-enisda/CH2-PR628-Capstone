package com.dicoding.capstone.signexpress.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.capstone.signexpress.R

class SubjectAdapter(private val subjects: List<Subject>) :
    RecyclerView.Adapter<SubjectAdapter.SubjectViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubjectViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_lesson, parent, false)
        return SubjectViewHolder(view)
    }

    override fun onBindViewHolder(holder: SubjectViewHolder, position: Int) {
        val subject = subjects[position]
        holder.bind(subject)
    }

    override fun getItemCount(): Int {
        return subjects.size
    }

    inner class SubjectViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.title_subject)
        private val descTextView: TextView = itemView.findViewById(R.id.desc_subject)
        private val nextImageView: ImageView = itemView.findViewById(R.id.next_subject)

        fun bind(subject: Subject) {
            titleTextView.text = subject.title
            descTextView.text = subject.description

            // Add any additional logic or listeners here

            nextImageView.setOnClickListener {
                // Handle the click event
            }
        }
    }
}